const deg = 6;
const hr = document.querySelector("#hr");
const mn = document.querySelector("#mn");
const sc = document.querySelector("#sc");

const timezoneoffset = -300;

setInterval(() => {
  let day = new Date();
  let hh = (day.getHours() +(timezoneoffset / 60)) % 12;
  let mm = day.getMinutes();
  let ss = day.getSeconds();

  hh = hh * 30 + mm /2;
  mm = mm * deg;
  ss = ss * deg;

  hr.style.transform = `rotateZ(${hh}deg)`;
  mn.style.transform = `rotateZ(${mm}deg`;
  sc.style.transform = `rotateZ(${ss}deg)`;
}, 1000);
